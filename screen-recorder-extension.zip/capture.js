// capture.js —— 区域框选 + 录制宿主
// 说明：浏览器禁止把 MediaStream 跨上下文传递，因此区域录制直接在本页面完成。
// 本页在录制期间不可关闭提示；录制结果（Blob URL）交给 background 下载。

const $ = id => document.getElementById(id);
const intro = $('intro'), stage = $('stage'), preview = $('preview');
const mask = $('mask'), sel = $('sel'), sizeTag = $('sizeTag'), tipBar = $('tipBar');
const btnShare = $('btnShare'), btnBack = $('btnBack');
const btnReset = $('btnReset'), btnConfirm = $('btnConfirm');
const loading = $('loading'), loadingText = $('loadingText'), errBox = $('errBox');
const optSys = $('optSys'), optMic = $('optMic');

let stream = null;
let region = null;          // 视频原始像素 {x,y,w,h}
let dragging = false;
let recorder = null;
let chunks = [];
let canvas = null, canvasStream = null, drawRAF = null;
let micStream = null, audioCtx = null;

// ---------- 阶段1：申请共享 ----------
btnShare.onclick = async () => {
  btnShare.disabled = true;
  errBox.textContent = '';
  loadingText.textContent = '请在弹出的窗口中选择要共享的屏幕…';
  loading.style.display = 'grid';
  try {
    stream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: 30 },
      audio: optSys.checked ? { echoCancellation: false, noiseSuppression: false } : false
    });
  } catch (e) {
    loading.style.display = 'none';
    btnShare.disabled = false;
    errBox.textContent = '获取屏幕共享失败：' + e.message;
    return;
  }

  preview.srcObject = stream;
  loadingText.textContent = '正在载入画面…';
  if (preview.readyState < 2) {
    await new Promise(r => preview.addEventListener('loadedmetadata', r, { once: true }));
    await new Promise(r => preview.addEventListener('playing', r, { once: true }));
  }
  await new Promise(r => setTimeout(r, 200));

  loading.style.display = 'none';
  intro.style.display = 'none';
  stage.style.display = 'block';
  tipBar.style.display = 'flex';
  alignOverlay();
};

btnBack.onclick = async () => {
  cleanupStream();
  await chrome.runtime.sendMessage({ type: 'CANCEL_REGION' }).catch(() => {});
  window.close();
};

function fail(msg) {
  loading.style.display = 'none';
  stage.style.display = 'none';
  tipBar.style.display = 'none';
  intro.style.display = 'block';
  btnShare.disabled = false;
  errBox.textContent = msg;
}

// ---------- 坐标对齐 ----------
let viewBox = { left: 0, top: 0, width: 0, height: 0, scale: 1 };
function alignOverlay() {
  const vw = preview.videoWidth, vh = preview.videoHeight;
  if (!vw) return;
  const pw = window.innerWidth, ph = window.innerHeight;
  const scale = Math.min(pw / vw, ph / vh);
  const dw = vw * scale, dh = vh * scale;
  viewBox = { left: (pw - dw) / 2, top: (ph - dh) / 2, width: dw, height: dh, scale };
  mask.style.left = viewBox.left + 'px';
  mask.style.top = viewBox.top + 'px';
  mask.style.width = viewBox.width + 'px';
  mask.style.height = viewBox.height + 'px';
  if (region) renderRegion();
}
window.addEventListener('resize', alignOverlay);

// ---------- 拖拽 ----------
let startX = 0, startY = 0;

mask.addEventListener('mousedown', e => {
  if (e.button !== 0) return;
  e.preventDefault();
  dragging = true;
  startX = e.clientX; startY = e.clientY;
  sel.style.display = 'block';
  btnConfirm.disabled = true;
  updateSel(startX, startY, 0, 0);
});

window.addEventListener('mousemove', e => {
  if (!dragging) return;
  updateSel(startX, startY, e.clientX - startX, e.clientY - startY);
});

window.addEventListener('mouseup', e => {
  if (!dragging) return;
  dragging = false;

  const b = viewBox;
  let x1 = clamp(Math.min(startX, e.clientX), b.left, b.left + b.width);
  let y1 = clamp(Math.min(startY, e.clientY), b.top, b.top + b.height);
  let x2 = clamp(Math.max(startX, e.clientX), b.left, b.left + b.width);
  let y2 = clamp(Math.max(startY, e.clientY), b.top, b.top + b.height);
  let w = x2 - x1, h = y2 - y1;

  if (w < 12 || h < 12) {
    sel.style.display = 'none';
    btnConfirm.disabled = true;
    tipBar.querySelector('.info').textContent = '选区太小，请按住鼠标拖拽框选（至少 12×12）';
    return;
  }

  const s = b.scale;
  const rx = Math.round((x1 - b.left) / s);
  const ry = Math.round((y1 - b.top) / s);
  const rw = Math.round(w / s);
  const rh = Math.round(h / s);

  region = {
    x: clamp(rx, 0, preview.videoWidth - 4),
    y: clamp(ry, 0, preview.videoHeight - 4),
    w: Math.min(rw, preview.videoWidth - rx),
    h: Math.min(rh, preview.videoHeight - ry)
  };

  renderRegion();
  btnConfirm.disabled = false;
  sizeTag.textContent = `${region.w} × ${region.h}`;
  tipBar.querySelector('.info').innerHTML =
    `已选择 <b>${region.w} × ${region.h}</b>　源画面 ${preview.videoWidth}×${preview.videoHeight}`;
});

function updateSel(x1, y1, dw, dh) {
  const b = viewBox;
  let x = clamp(Math.min(x1, x1 + dw), b.left, b.left + b.width);
  let y = clamp(Math.min(y1, y1 + dh), b.top, b.top + b.height);
  let w = Math.min(Math.abs(dw), b.left + b.width - x);
  let h = Math.min(Math.abs(dh), b.top + b.height - y);

  sel.style.left = x + 'px';
  sel.style.top = y + 'px';
  sel.style.width = w + 'px';
  sel.style.height = h + 'px';

  const s = b.scale || 1;
  sizeTag.style.display = 'block';
  sizeTag.textContent = `${Math.round(w / s)} × ${Math.round(h / s)}`;
  sizeTag.style.left = clamp(x + 4, 0, window.innerWidth - 120) + 'px';
  sizeTag.style.top = (y - 30 < 0 ? y + 6 : y - 30) + 'px';
}

function renderRegion() {
  const b = viewBox, s = b.scale || 1;
  sel.style.display = 'block';
  sel.style.left = (b.left + region.x * s) + 'px';
  sel.style.top = (b.top + region.y * s) + 'px';
  sel.style.width = (region.w * s) + 'px';
  sel.style.height = (region.h * s) + 'px';
}

function clamp(v, a, b) { return Math.max(a, Math.min(v, b)); }

btnReset.onclick = () => {
  region = null;
  sel.style.display = 'none';
  sizeTag.style.display = 'none';
  btnConfirm.disabled = true;
  tipBar.querySelector('.info').textContent = '按住鼠标拖拽框选区域';
};

// ---------- 确认并录制（本页作为录制宿主） ----------
btnConfirm.onclick = async () => {
  if (!region) return;
  btnConfirm.disabled = true;
  btnReset.disabled = true;
  loadingText.textContent = '正在启动录制…';
  loading.style.display = 'grid';

  try {
    // 保证偶数尺寸
    let w = Math.max(2, Math.floor(region.w / 2) * 2);
    let h = Math.max(2, Math.floor(region.h / 2) * 2);

    canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });

    const draw = () => {
      if (preview.readyState >= 2) {
        try { ctx.drawImage(preview, region.x, region.y, w, h, 0, 0, w, h); } catch (e) {}
      }
      drawRAF = requestAnimationFrame(draw);
    };
    draw();

    canvasStream = canvas.captureStream(30);
    const finalStream = new MediaStream();
    canvasStream.getVideoTracks().forEach(t => finalStream.addTrack(t));

    // 音频：系统声音 + 麦克风混合
    const sysTracks = stream.getAudioTracks();
    if (optMic.checked) {
      try {
        micStream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true }
        });
      } catch (e) { console.warn('mic failed', e); }
    }

    let hasAudio = false;
    if (sysTracks.length || micStream) {
      audioCtx = new AudioContext();
      const dest = audioCtx.createMediaStreamDestination();
      if (sysTracks.length) audioCtx.createMediaStreamSource(new MediaStream(sysTracks)).connect(dest);
      if (micStream) audioCtx.createMediaStreamSource(micStream).connect(dest);
      dest.stream.getAudioTracks().forEach(t => finalStream.addTrack(t));
      hasAudio = true;
    }

    const mime = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']
      .find(m => MediaRecorder.isTypeSupported(m)) || 'video/webm';

    recorder = new MediaRecorder(finalStream, { mimeType: mime, videoBitsPerSecond: 8000000 });
    chunks = [];
    recorder.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
    recorder.onstop = onRecordStop;
    recorder.start(1000);

    // 通知 background 状态
    await chrome.runtime.sendMessage({
      type: 'REC_STATUS',
      patch: {
        status: 'recording', mode: 'region',
        startedAt: Date.now(), pausedAccum: 0, pausedAt: 0,
        region, hasSysAudio: sysTracks.length > 0, hasMic: !!micStream,
        host: 'capture-tab'
      }
    }).catch(() => {});

    // 切换到录制中界面
    loading.style.display = 'none';
    enterRecordingUI(w, h, hasAudio);

    // 用户点浏览器"停止共享" -> 自动收尾
    stream.getVideoTracks()[0].addEventListener('ended', () => {
      if (recorder && recorder.state !== 'inactive') recorder.stop();
    });

  } catch (e) {
    loading.style.display = 'none';
    btnConfirm.disabled = false;
    btnReset.disabled = false;
    fail('启动录制失败：' + e.message);
  }
};

// ---------- 录制中界面 ----------
let recTimerRAF = null, recStart = 0;
function enterRecordingUI(w, h, hasAudio) {
  stage.style.display = 'none';
  tipBar.style.display = 'none';
  intro.style.display = 'block';
  intro.innerHTML = `
    <h1><span style="color:#e94560">●</span> 正在录制区域</h1>
    <p style="margin-bottom:18px;">
      区域尺寸 <b style="color:#4caf50;font-family:Consolas">${w} × ${h}</b>
      ${hasAudio ? '　·　已启用音频' : '　·　无音频'}
    </p>
    <div style="font-size:56px;font-family:Consolas,monospace;color:#e94560;letter-spacing:3px;margin-bottom:20px;" id="recTimer">00:00:00</div>
    <p style="color:#8b93a8;font-size:13px;margin-bottom:24px;line-height:1.8;">
      请保持本标签页打开（可切换到其他标签页，但不要关闭）<br>
      录制过程中可点击浏览器工具栏的插件图标查看/停止
    </p>
    <div>
      <button class="btn btn-cancel" id="btnRecStop">停止并保存</button>
      <button class="btn btn-go" id="btnRecPause">暂停</button>
    </div>
    <div class="err" id="recErr"></div>
  `;

  recStart = Date.now();
  let pausedAccum = 0, pauseAt = 0;

  const tick = () => {
    if (!recorder) return;
    const now = (recorder.state === 'paused' && pauseAt) ? pauseAt : Date.now();
    const s = Math.max(0, Math.floor((now - recStart - pausedAccum) / 1000));
    const el = document.getElementById('recTimer');
    if (el) el.textContent = fmt(s);
    if (recorder.state !== 'inactive') recTimerRAF = setTimeout(tick, 400);
  };
  tick();

  document.getElementById('btnRecStop').onclick = () => {
    if (recorder && recorder.state !== 'inactive') recorder.stop();
    document.getElementById('btnRecStop').disabled = true;
  };

  // 暂停/继续统一切换函数
  window.__togglePause = () => {
    if (!recorder) return;
    const btn = document.getElementById('btnRecPause');
    if (recorder.state === 'recording') {
      recorder.pause();
      pauseAt = Date.now();
      if (btn) btn.textContent = '继续';
      chrome.runtime.sendMessage({ type: 'REC_STATUS', patch: { status: 'paused', pausedAt: pauseAt } }).catch(() => {});
    } else if (recorder.state === 'paused') {
      recorder.resume();
      pausedAccum += Date.now() - pauseAt;
      pauseAt = 0;
      if (btn) btn.textContent = '暂停';
      chrome.runtime.sendMessage({ type: 'REC_STATUS', patch: { status: 'recording', pausedAccum, pausedAt: 0 } }).catch(() => {});
    }
  };
  document.getElementById('btnRecPause').onclick = window.__togglePause;
}

function fmt(s) {
  return [Math.floor(s / 3600), Math.floor(s % 3600 / 60), s % 60]
    .map(n => String(n).padStart(2, '0')).join(':');
}

// ---------- 收尾：生成文件并交给 background 下载 ----------
function onRecordStop() {
  if (recTimerRAF) clearTimeout(recTimerRAF);
  if (drawRAF) cancelAnimationFrame(drawRAF);

  const type = (recorder && recorder.mimeType) || 'video/webm';
  const blob = new Blob(chunks, { type });
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
  const filename = `录屏_${stamp}_区域.webm`;

  // 通过 FileReader 转 dataURL 传给 background（tab 关闭后 blob URL 会失效）
  const reader = new FileReader();
  reader.onload = () => {
    chrome.runtime.sendMessage({
      type: 'REC_DONE',
      dataUrl: reader.result,
      filename,
      sizeMB: (blob.size / 1048576).toFixed(2)
    }).catch(() => {});
    cleanupAll();
    // 显示完成提示
    intro.innerHTML = `
      <h1>✅ 录制完成</h1>
      <p style="margin-bottom:22px;">文件 ${filename}（${(blob.size/1048576).toFixed(2)} MB）已提交保存</p>
      <button class="btn btn-go" id="btnDone">关闭页面</button>
    `;
    intro.style.display = 'block';
    const b = document.getElementById('btnDone');
    if (b) b.onclick = () => window.close();
  };
  reader.readAsDataURL(blob);
}

function cleanupStream() {
  if (stream) stream.getTracks().forEach(t => t.stop());
  stream = null;
}

function cleanupAll() {
  if (drawRAF) cancelAnimationFrame(drawRAF);
  [stream, micStream, canvasStream].forEach(s => { if (s) s.getTracks().forEach(t => t.stop()); });
  if (audioCtx) { audioCtx.close().catch(() => {}); audioCtx = null; }
  stream = micStream = canvasStream = null;
  preview.srcObject = null;
}

window.addEventListener('beforeunload', e => {
  if (recorder && recorder.state !== 'inactive') {
    e.preventDefault();
    e.returnValue = '正在录制中，关闭将丢失本次录制';
    return e.returnValue;
  }
  cleanupAll();
});

// ---------- 接收 popup 的远程控制 ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === 'REMOTE_STOP') {
    if (recorder && recorder.state !== 'inactive') recorder.stop();
    sendResponse({ ok: true });
  }
  if (msg.type === 'REMOTE_PAUSE_TOGGLE') {
    if (window.__togglePause) window.__togglePause();
    sendResponse({ ok: true });
  }
});

// ---------- 初始检查 ----------
(async () => {
  // 读取 popup 中的音频偏好
  try {
    const prefs = await chrome.storage.local.get(['sysAudio', 'micAudio']);
    if (prefs.sysAudio !== undefined) optSys.checked = prefs.sysAudio;
    if (prefs.micAudio !== undefined) optMic.checked = prefs.micAudio;
  } catch (e) {}

  const st = await chrome.runtime.sendMessage({ type: 'GET_STATE' }).catch(() => null);
  if (st && (st.status === 'recording' || st.status === 'paused') && st.host !== 'capture-tab') {
    fail('已有录制任务进行中，请先在插件面板停止后再框选新区域');
  }
})();
