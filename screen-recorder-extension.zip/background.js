// background.js - Service Worker
// 负责：调度 offscreen 录制引擎、管理区域框选页、下载保存、消息路由

const STATE_KEY = 'recorderState';
const CAPTURE_URL = 'capture.html';

let state = {
  status: 'idle',      // idle | recording | paused
  mode: 'full',
  startedAt: 0,
  pausedAccum: 0,
  pausedAt: 0,
  region: null,
  hasMic: false,
  hasSysAudio: false
};

function persistState() {
  return chrome.storage.session.set({ [STATE_KEY]: state }).catch(() => {});
}

async function setState(patch) {
  state = { ...state, ...patch };
  await persistState();
  chrome.runtime.sendMessage({ type: 'STATE_UPDATE', state }).catch(() => {});
  updateBadge(state.status);
}

async function loadState() {
  try {
    const got = await chrome.storage.session.get(STATE_KEY);
    if (got[STATE_KEY]) state = got[STATE_KEY];
  } catch (e) {}
  return state;
}

function updateBadge(status) {
  const map = {
    recording: ['REC', '#e94560'],
    paused: ['PAUSE', '#ff9800']
  };
  const [text, color] = map[status] || ['', '#000000'];
  chrome.action.setBadgeText({ text }).catch(() => {});
  if (text) chrome.action.setBadgeBackgroundColor({ color }).catch(() => {});
}

// ---------- offscreen 管理 ----------
async function ensureOffscreen() {
  if (chrome.runtime.getContexts) {
    const ctxs = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (ctxs.length) return;
  }
  try {
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['DISPLAY_MEDIA', 'USER_MEDIA', 'AUDIO_PLAYBACK'],
      justification: '后台持续录制屏幕画面与音频，popup 关闭后仍需保持录制'
    });
  } catch (e) {
    if (!/single offscreen|already exists/i.test(String(e.message))) throw e;
  }
  await new Promise(r => setTimeout(r, 350));
}

async function closeOffscreen() {
  try { await chrome.offscreen.closeDocument(); } catch (e) {}
}

async function toOffscreen(action, extra = {}) {
  try {
    await ensureOffscreen();
    const res = await chrome.runtime.sendMessage({ target: 'offscreen', action, ...extra });
    return res || { ok: false, error: '录制引擎无响应' };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ---------- 框选页管理 ----------
async function openCaptureTab() {
  const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL(CAPTURE_URL) });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    return tabs[0].id;
  }
  const tab = await chrome.tabs.create({ url: chrome.runtime.getURL(CAPTURE_URL), active: true });
  return tab.id;
}

async function closeCaptureTabs() {
  const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL(CAPTURE_URL) });
  for (const t of tabs) {
    try { await chrome.tabs.remove(t.id); } catch (e) {}
  }
}

// ---------- 消息路由 ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;
  if (msg.target === 'offscreen') return; // 放行给 offscreen

  (async () => {
    switch (msg.type) {

      case 'START_FULL': {
        sendResponse(await toOffscreen('start', {
          mode: 'full', mic: msg.mic, sysAudio: msg.sysAudio
        }));
        break;
      }

      case 'OPEN_REGION_SELECTOR': {
        await setState({ mode: 'region' });
        await openCaptureTab();
        sendResponse({ ok: true });
        break;
      }

      case 'REGION_SELECTED': {
        const res = await toOffscreen('start', {
          mode: 'region',
          region: msg.region,
          mic: msg.mic,
          sysAudio: msg.sysAudio
        });
        sendResponse(res);
        if (res && res.ok) await closeCaptureTabs();
        break;
      }

      case 'CANCEL_REGION': {
        await closeCaptureTabs();
        sendResponse({ ok: true });
        break;
      }

      case 'REC_STATUS': {
        await setState(msg.patch || {});
        sendResponse({ ok: true });
        break;
      }

      case 'REC_DONE': {
        const downloadUrl = msg.dataUrl || msg.url;
        try {
          await chrome.downloads.download({ url: downloadUrl, filename: msg.filename, saveAs: true });
        } catch (e) { console.warn('download failed:', e.message); }
        await setState({
          status: 'idle', region: null, startedAt: 0,
          pausedAccum: 0, pausedAt: 0, mode: 'full',
          hasMic: false, hasSysAudio: false
        });
        // 通知 popup 显示完成提示
        chrome.runtime.sendMessage({
          type: 'REC_SAVED', filename: msg.filename, sizeMB: msg.sizeMB
        }).catch(() => {});
        await closeOffscreen();
        try {
          chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: '录制完成',
            message: `${msg.filename}（${msg.sizeMB} MB）已保存`
          });
        } catch (e) {}
        sendResponse({ ok: true });
        break;
      }

      case 'PAUSE':  { sendResponse(await toOffscreen('pause')); break; }
      case 'RESUME': { sendResponse(await toOffscreen('resume')); break; }
      case 'STOP':   { sendResponse(await toOffscreen('stop')); break; }

      case 'GET_STATE': {
        sendResponse(await loadState());
        break;
      }
    }
  })();
  return true;
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.session.set({ [STATE_KEY]: state });
  chrome.action.setBadgeText({ text: '' }).catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  chrome.action.setBadgeText({ text: '' }).catch(() => {});
});
