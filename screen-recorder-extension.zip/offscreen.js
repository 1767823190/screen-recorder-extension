// offscreen.js
// 在 offscreen document 中运行实际的 MediaRecorder，popup 关闭也不会中断录制。

let screenStream = null;
let micStream = null;
let audioCtx = null;
let recorder = null;
let chunks = [];
let canvas = null;
let canvasStream = null;
let drawRAF = null;
let videoEl = null;
let region = null;
let pausedAccum = 0;
let pauseAt = 0;
let stopping = false;

function log(...a) { console.log('[recorder]', ...a); }

function tell(patch) {
  chrome.runtime.sendMessage({ type: 'REC_STATUS', patch }).catch(() => {});
}

function pickMime() {
  const list = [
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm'
  ];
  for (const m of list) {
    if (MediaRecorder.isTypeSupported(m)) return { mimeType: m, videoBitsPerSecond: 8000000 };
  }
  return {};
}

// 区域裁剪：region 为相对视频原始像素坐标
async function buildRegionStream(srcStream) {
  videoEl = document.createElement('video');
  videoEl.muted = true;
  videoEl.playsInline = true;
  videoEl.srcObject = srcStream;
  await videoEl.play();
  await new Promise(res => {
    if (videoEl.videoWidth > 0) return res();
    videoEl.addEventListener('loadedmetadata', res, { once: true });
  });
  await new Promise(r => setTimeout(r, 150)); // 等首帧渲染

  const vw = videoEl.videoWidth, vh = videoEl.videoHeight;
  let { x, y, w, h } = region;
  x = Math.max(0, Math.min(Math.round(x), vw - 4));
  y = Math.max(0, Math.min(Math.round(y), vh - 4));
  w = Math.min(Math.round(w), vw - x);
  h = Math.min(Math.round(h), vh - y);
  w = Math.max(2, Math.floor(w / 2) * 2);  // 偶数尺寸，避免编码器报错
  h = Math.max(2, Math.floor(h / 2) * 2);

  canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });

  const draw = () => {
    if (videoEl && videoEl.readyState >= 2) {
      try { ctx.drawImage(videoEl, x, y, w, h, 0, 0, w, h); } catch (e) {}
    }
    drawRAF = requestAnimationFrame(draw);
  };
  draw();

  canvasStream = canvas.captureStream(30);
  log('region', `${w}x${h}`, 'offset', x, y, 'source', `${vw}x${vh}`);
}

async function mixAudio() {
  const sysTracks = screenStream.getAudioTracks();
  if (!sysTracks.length && !micStream) return null;
  audioCtx = new AudioContext();
  const dest = audioCtx.createMediaStreamDestination();
  if (sysTracks.length) audioCtx.createMediaStreamSource(new MediaStream(sysTracks)).connect(dest);
  if (micStream) audioCtx.createMediaStreamSource(micStream).connect(dest);
  return dest.stream;
}

async function start({ mode, region: r, mic, sysAudio }) {
  try {
    region = r || null;
    pausedAccum = 0; pauseAt = 0; stopping = false; chunks = [];

    // 1. 屏幕流（区域模式也需先共享屏幕，再裁剪）
    screenStream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: 30 },
      audio: sysAudio ? { echoCancellation: false, noiseSuppression: false } : false
    });

    if (mode === 'region' && !region) throw new Error('区域录制缺少选区信息');

    // 2. 麦克风：录制开始前就绪，确保音轨被编码
    if (mic) {
      try {
        micStream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true }
        });
      } catch (e) { log('mic failed:', e.message); }
    }

    // 3. 组装最终流
    const finalStream = new MediaStream();
    let firstVideoTrack;
    if (mode === 'region') {
      await buildRegionStream(screenStream);
      firstVideoTrack = canvasStream.getVideoTracks()[0];
      finalStream.addTrack(firstVideoTrack);
    } else {
      firstVideoTrack = screenStream.getVideoTracks()[0];
      finalStream.addTrack(firstVideoTrack);
    }
    const audio = await mixAudio();
    if (audio) audio.getAudioTracks().forEach(t => finalStream.addTrack(t));

    // 4. 录制
    recorder = new MediaRecorder(finalStream, pickMime());
    recorder.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
    recorder.onstop = finish;
    recorder.start(1000);

    // 用户点击浏览器"停止共享"时自动收尾
    firstVideoTrack.addEventListener('ended', () => {
      if (recorder && recorder.state !== 'inactive') recorder.stop();
    });

    tell({
      status: 'recording',
      startedAt: Date.now(),
      pausedAccum: 0,
      pausedAt: 0,
      mode,
      hasMic: !!micStream,
      hasSysAudio: screenStream.getAudioTracks().length > 0
    });
    return { ok: true };
  } catch (e) {
    log('start failed:', e.message);
    cleanup();
    return { ok: false, error: e.message };
  }
}

function finish() {
  if (stopping) return;
  stopping = true;
  const type = (recorder && recorder.mimeType) || 'video/webm';
  const blob = new Blob(chunks, { type });
  const url = URL.createObjectURL(blob);
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
  const suffix = region ? '_区域' : '_全屏';
  const filename = `录屏_${stamp}${suffix}.webm`;

  chrome.runtime.sendMessage({
    type: 'REC_DONE',
    url,
    filename,
    sizeMB: (blob.size / 1048576).toFixed(2)
  }).catch(() => {});

  release();
}

function release() {
  if (drawRAF) { cancelAnimationFrame(drawRAF); drawRAF = null; }
  [screenStream, micStream, canvasStream].forEach(s => {
    if (s) s.getTracks().forEach(t => t.stop());
  });
  screenStream = micStream = canvasStream = null;
  if (audioCtx) { audioCtx.close().catch(() => {}); audioCtx = null; }
  if (videoEl) { videoEl.srcObject = null; videoEl = null; }
  canvas = null; recorder = null; region = null;
}

function cleanup() {
  if (recorder && recorder.state !== 'inactive') {
    try { recorder.stop(); } catch (e) {}
    return; // onstop -> finish -> release
  }
  release();
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen') return;
  (async () => {
    switch (msg.action) {
      case 'start':
        sendResponse(await start(msg));
        break;
      case 'pause':
        if (recorder && recorder.state === 'recording') {
          recorder.pause();
          pauseAt = Date.now();
          tell({ status: 'paused', pausedAt: pauseAt });
        }
        sendResponse({ ok: true });
        break;
      case 'resume':
        if (recorder && recorder.state === 'paused') {
          recorder.resume();
          pausedAccum += Date.now() - pauseAt;
          pauseAt = 0;
          tell({ status: 'recording', pausedAccum, pausedAt: 0 });
        }
        sendResponse({ ok: true });
        break;
      case 'stop':
        if (recorder && recorder.state !== 'inactive') recorder.stop();
        sendResponse({ ok: true });
        break;
      case 'cancel':
        cleanup();
        sendResponse({ ok: true });
        break;
    }
  })();
  return true;
});
