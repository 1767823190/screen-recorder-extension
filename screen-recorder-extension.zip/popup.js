/* popup.js */
const $ = id => document.getElementById(id);
const mFull = $('mFull'), mRegion = $('mRegion');
const swSys = $('swSys'), swMic = $('swMic');
const btnStart = $('btnStart');
const idlePanel = $('idlePanel'), recPanel = $('recPanel');
const btnPause = $('btnPause'), btnStop = $('btnStop');
const timerEl = $('timer'), badgesEl = $('badges');
const statusIdle = $('statusIdle'), statusRec = $('statusRec');

let mode = 'full';
let state = { status: 'idle' };
let timerId = null;

// ---------- 偏好持久化 ----------
chrome.storage.local.get(['mode', 'sysAudio', 'micAudio'], s => {
  if (s.mode) setMode(s.mode, true);
  if (s.sysAudio !== undefined) swSys.checked = s.sysAudio;
  if (s.micAudio !== undefined) swMic.checked = s.micAudio;
});
function savePrefs() {
  chrome.storage.local.set({ mode, sysAudio: swSys.checked, micAudio: swMic.checked });
}
swSys.onchange = savePrefs;
swMic.onchange = savePrefs;

// ---------- 模式 ----------
[mFull, mRegion].forEach(el => {
  el.onclick = () => {
    if (state.status !== 'idle') return;
    setMode(el.dataset.mode);
  };
});
function setMode(m, silent) {
  mode = m;
  mFull.classList.toggle('active', m === 'full');
  mRegion.classList.toggle('active', m === 'region');
  if (!silent) {
    statusIdle.className = 'status';
    statusIdle.textContent = m === 'region'
      ? '点击开始后将打开框选页，在画面上拖拽选择区域'
      : '选择模式后点击开始';
  }
  savePrefs();
}

// ---------- 计时 ----------
function elapsed() {
  if (!state.startedAt) return 0;
  const now = (state.status === 'paused' && state.pausedAt) ? state.pausedAt : Date.now();
  return Math.max(0, Math.floor((now - state.startedAt - (state.pausedAccum || 0)) / 1000));
}
function fmt(s) {
  return [Math.floor(s / 3600), Math.floor(s % 3600 / 60), s % 60]
    .map(n => String(n).padStart(2, '0')).join(':');
}

// ---------- 渲染 ----------
function render() {
  const rec = state.status === 'recording' || state.status === 'paused';

  idlePanel.classList.toggle('hidden', rec);
  recPanel.classList.toggle('hidden', !rec);
  mFull.classList.toggle('disabled', rec);
  mRegion.classList.toggle('disabled', rec);

  if (timerId) { clearInterval(timerId); timerId = null; }

  if (!rec) {
    timerEl.textContent = '00:00:00';
    return;
  }

  timerEl.textContent = fmt(elapsed());
  timerEl.classList.toggle('paused', state.status === 'paused');

  const list = [];
  list.push(`<span class="badge">${state.mode === 'region' ? '✂️ 区域录制' : '🖥 全屏/窗口'}</span>`);
  if (state.hasSysAudio) list.push('<span class="badge on">🔊 系统声音</span>');
  if (state.hasMic) list.push('<span class="badge on">🎤 麦克风</span>');
  if (!state.hasSysAudio && !state.hasMic) list.push('<span class="badge">无音频</span>');
  if (state.host === 'capture-tab') list.push('<span class="badge">📄 框选页宿主</span>');
  badgesEl.innerHTML = list.join('');

  if (state.status === 'paused') {
    btnPause.textContent = '继续';
    statusRec.innerHTML = '<span class="rec-dot" style="background:#ffa726"></span>已暂停';
  } else {
    btnPause.textContent = '暂停';
    statusRec.innerHTML = state.host === 'capture-tab'
      ? '<span class="rec-dot"></span>录制中 · 请勿关闭框选页'
      : '<span class="rec-dot"></span>录制中 · 可关闭本面板';
  }

  timerId = setInterval(() => {
    if (state.status === 'recording') timerEl.textContent = fmt(elapsed());
  }, 500);
}

// ---------- 消息 ----------
chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'STATE_UPDATE') {
    state = msg.state;
    render();
  }
  if (msg.type === 'REC_SAVED') {
    state.status = 'idle';
    render();
    statusIdle.className = 'status ok';
    statusIdle.textContent = `已保存 ${msg.filename}（${msg.sizeMB} MB）`;
  }
});

// ---------- 开始 ----------
btnStart.onclick = async () => {
  btnStart.disabled = true;
  statusIdle.className = 'status';
  statusIdle.textContent = mode === 'region' ? '正在打开框选页…' : '正在请求屏幕共享权限…';

  try {
    if (mode === 'region') {
      const r = await chrome.runtime.sendMessage({ type: 'OPEN_REGION_SELECTOR' });
      if (!r || !r.ok) throw new Error(r && r.error || '无法打开框选页');
      statusIdle.className = 'status ok';
      statusIdle.textContent = '框选页已打开，请在页面上拖拽选择区域';
      // 把音频偏好写入 storage，供框选页读取
      chrome.storage.local.set({ sysAudio: swSys.checked, micAudio: swMic.checked });
      return;
    }
    const r = await chrome.runtime.sendMessage({
      type: 'START_FULL', mic: swMic.checked, sysAudio: swSys.checked
    });
    if (!r || !r.ok) throw new Error(r && r.error || '启动录制失败');
    const s = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
    state = s || state;
    render();
  } catch (e) {
    statusIdle.className = 'status err';
    statusIdle.textContent = '错误：' + e.message;
  } finally {
    btnStart.disabled = false;
  }
};

// ---------- 暂停/继续/停止 ----------
btnPause.onclick = async () => {
  btnPause.disabled = true;
  try {
    if (state.host === 'capture-tab') {
      // 由框选页自行控制，这里通过消息请它处理
      const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL('capture.html') });
      if (tabs.length) {
        await chrome.tabs.sendMessage(tabs[0].id, {
          type: 'REMOTE_PAUSE_TOGGLE'
        }).catch(() => {});
      }
      // 状态会由框选页回报
      setTimeout(async () => {
        const s = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
        state = s || state;
        render();
      }, 250);
    } else {
      await chrome.runtime.sendMessage({ type: state.status === 'paused' ? 'RESUME' : 'PAUSE' });
      state.status = state.status === 'paused' ? 'recording' : 'paused';
      if (state.status === 'paused') state.pausedAt = Date.now();
      render();
    }
  } catch (e) {
    statusRec.textContent = '操作失败：' + e.message;
  } finally {
    btnPause.disabled = false;
  }
};

btnStop.onclick = async () => {
  btnStop.disabled = true;
  statusRec.textContent = '正在生成文件…';
  try {
    if (state.host === 'capture-tab') {
      const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL('capture.html') });
      if (tabs.length) {
        await chrome.tabs.sendMessage(tabs[0].id, { type: 'REMOTE_STOP' }).catch(() => {});
      }
    } else {
      await chrome.runtime.sendMessage({ type: 'STOP' });
    }
  } catch (e) {
    statusRec.textContent = '停止失败：' + e.message;
  }
  setTimeout(() => { btnStop.disabled = false; }, 1200);
};

// ---------- 帮助 ----------
$('linkHelp').onclick = e => {
  e.preventDefault();
  statusIdle.className = 'status';
  statusIdle.innerHTML =
    '<b>全屏/窗口</b>：点开始后在弹窗选择屏幕或窗口<br>' +
    '<b>自选区域</b>：在打开的框选页拖拽选区，自动裁剪录制<br>' +
    '<b>录制中</b>：可关闭本面板，录制继续（区域模式勿关闭框选页）<br>' +
    '<b>停止后</b>：选择保存位置，默认 .webm 格式';
};

// ---------- 初始化 ----------
(async () => {
  const s = await chrome.runtime.sendMessage({ type: 'GET_STATE' }).catch(() => null);
  if (s) state = s;
  render();
})();
