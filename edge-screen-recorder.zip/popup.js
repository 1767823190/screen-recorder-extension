// popup.js —— Edge 扩展控制面板
const $ = id => document.getElementById(id);
const mFull = $('mFull'), mRegion = $('mRegion');
const swSys = $('swSys'), swMic = $('swMic');
const btnStart = $('btnStart');
const idlePanel = $('idlePanel'), recPanel = $('recPanel');
const btnPause = $('btnPause'), btnStop = $('btnStop');
const timerEl = $('timer'), recDot = $('recDot'), recStateText = $('recStateText');
const pillsEl = $('pills'), statusIdle = $('statusIdle'), statusRec = $('statusRec');
const helpBox = $('helpBox');

let mode = 'full';
let state = { status: 'idle' };
let tickId = null;

// ================= 偏好持久化 =================
async function loadPrefs() {
  try {
    const s = await chrome.storage.local.get(['mode', 'sysAudio', 'micAudio']);
    if (s.mode === 'full' || s.mode === 'region') mode = s.mode;
    if (s.sysAudio !== undefined) swSys.checked = s.sysAudio;
    if (s.micAudio !== undefined) swMic.checked = s.micAudio;
  } catch (e) {}
  syncModeUI();
}

function savePrefs() {
  chrome.storage.local.set({
    mode,
    sysAudio: swSys.checked,
    micAudio: swMic.checked
  }).catch(() => {});
}

swSys.onchange = savePrefs;
swMic.onchange = savePrefs;

// ================= 模式 =================
[mFull, mRegion].forEach(el => {
  el.onclick = () => {
    if (state.status !== 'idle') return;
    mode = el.dataset.mode;
    syncModeUI();
    savePrefs();
    statusIdle.className = 'status';
    statusIdle.textContent = mode === 'region'
      ? '将打开框选页，先共享屏幕再拖拽选区'
      : '将打开录制页，在弹窗中选择屏幕或窗口';
  };
});

function syncModeUI() {
  mFull.classList.toggle('active', mode === 'full');
  mRegion.classList.toggle('active', mode === 'region');
}

// ================= 计时 =================
function elapsedSec() {
  if (!state.startedAt) return 0;
  const now = (state.status === 'paused' && state.pausedAt) ? state.pausedAt : Date.now();
  return Math.max(0, Math.floor((now - state.startedAt - (state.pausedAccum || 0)) / 1000));
}

function fmt(s) {
  return [Math.floor(s / 3600), Math.floor(s % 3600 / 60), s % 60]
    .map(n => String(n).padStart(2, '0')).join(':');
}

// ================= 渲染 =================
function render() {
  const isRec = state.status === 'recording' || state.status === 'paused';

  idlePanel.classList.toggle('hidden', isRec);
  recPanel.style.display = isRec ? 'block' : 'none';

  mFull.classList.toggle('disabled', isRec);
  mRegion.classList.toggle('disabled', isRec);

  if (tickId) { clearInterval(tickId); tickId = null; }

  if (!isRec) {
    timerEl.textContent = '00:00:00';
    timerEl.classList.remove('paused');
    return;
  }

  // 计时
  timerEl.textContent = fmt(elapsedSec());
  timerEl.classList.toggle('paused', state.status === 'paused');

  // 状态文字
  const paused = state.status === 'paused';
  recDot.classList.toggle('paused', paused);
  btnPause.textContent = paused ? '继续' : '暂停';

  if (paused) {
    recStateText.textContent = '已暂停';
  } else if (state.host === 'capture-tab') {
    recStateText.textContent = '区域录制中';
  } else {
    recStateText.textContent = '正在录制';
  }

  // 徽章
  const pills = [];
  pills.push(`<span class="pill">${state.mode === 'region' ? '✂️ 区域' : '🖥 全屏/窗口'}</span>`);
  if (state.mode === 'region' && state.region) {
    pills.push(`<span class="pill">${state.region.w} × ${state.region.h}</span>`);
  }
  if (state.hasSysAudio) pills.push('<span class="pill ok">🔊 系统声音</span>');
  if (state.hasMic) pills.push('<span class="pill ok">🎤 麦克风</span>');
  if (!state.hasSysAudio && !state.hasMic) pills.push('<span class="pill warn">无音频</span>');
  pillsEl.innerHTML = pills.join('');

  // 提示
  if (state.host) {
    statusRec.className = 'status';
    statusRec.textContent = state.host === 'capture-tab'
      ? '录制在框选页进行，请勿关闭该标签页'
      : '录制在录制页进行，请勿关闭该标签页（可切换标签）';
  }

  // 本地补帧（保证秒数平滑）
  tickId = setInterval(() => {
    if (state.status === 'recording') {
      timerEl.textContent = fmt(elapsedSec());
    }
  }, 500);
}

// ================= 消息 =================
chrome.runtime.onMessage.addListener(msg => {
  if (!msg) return;
  if (msg.type === 'STATE_UPDATE') {
    state = msg.state;
    render();
  }
  if (msg.type === 'REC_SAVED') {
    state.status = 'idle';
    state.host = null;
    render();
    statusIdle.className = 'status ok';
    statusIdle.innerHTML =
      `已保存 <b style="color:#66bb6a">${escapeHtml(msg.filename)}</b><br>${msg.sizeMB} MB`;
  }
});

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

// ================= 开始 =================
btnStart.onclick = async () => {
  btnStart.disabled = true;
  statusIdle.className = 'status';
  statusIdle.textContent = '正在打开录制页面…';

  const payload = {
    mic: swMic.checked,
    sysAudio: swSys.checked
  };

  try {
    const type = mode === 'region' ? 'START_REGION' : 'START_FULL';
    const r = await chrome.runtime.sendMessage({ type, ...payload });

    if (!r || !r.ok) throw new Error((r && r.error) || '打开录制页失败');

    statusIdle.className = 'status ok';
    statusIdle.textContent = mode === 'region'
      ? '框选页已打开，请先共享屏幕再拖拽选区'
      : '录制页已打开，请在弹窗中选择屏幕或窗口';

    // 稍等页面初始化后刷新状态
    setTimeout(refreshState, 900);

  } catch (e) {
    statusIdle.className = 'status err';
    statusIdle.textContent = '错误：' + e.message;
  } finally {
    btnStart.disabled = false;
  }
};

// ================= 暂停 / 继续 =================
btnPause.onclick = async () => {
  btnPause.disabled = true;
  try {
    const r = await chrome.runtime.sendMessage({ type: 'PAUSE_TOGGLE' });
    if (!r || !r.ok) throw new Error((r && r.error) || '操作失败');
    // 状态由页面回报，稍等再取一次
    setTimeout(refreshState, 250);
  } catch (e) {
    statusRec.className = 'status err';
    statusRec.textContent = e.message;
  } finally {
    btnPause.disabled = false;
  }
};

// ================= 停止 =================
btnStop.onclick = async () => {
  btnStop.disabled = true;
  statusRec.className = 'status';
  statusRec.textContent = '正在生成文件…';
  try {
    const r = await chrome.runtime.sendMessage({ type: 'STOP' });
    if (!r || !r.ok) throw new Error((r && r.error) || '停止失败');
  } catch (e) {
    statusRec.className = 'status err';
    statusRec.textContent = '停止失败：' + e.message;
  }
  setTimeout(() => { btnStop.disabled = false; }, 1500);
};

// ================= 帮助 =================
$('linkHelp').onclick = e => {
  e.preventDefault();
  helpBox.style.display = helpBox.style.display === 'block' ? 'none' : 'block';
};

// ================= 初始化 =================
async function refreshState() {
  try {
    const s = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
    if (s) state = s;
  } catch (e) {}
  render();
}

(async () => {
  await loadPrefs();
  await refreshState();
})();
