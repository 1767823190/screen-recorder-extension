// recorder.js —— 全屏 / 窗口录制宿主页（Edge）
// 说明：Edge 中 getDisplayMedia 必须由具备用户手势的页面调用，
//       因此全屏录制在本标签页完成，录制期间请勿关闭本页。

const $ = id => document.getElementById(id);
const readyPanel = $('readyPanel'), recPanel = $('recPanel'), donePanel = $('donePanel');
const optSys = $('optSys'), optMic = $('optMic');
const btnStart = $('btnStart'), btnCancel = $('btnCancel');
const btnPause = $('btnPause'), btnStop = $('btnStop');
const btnAgain = $('btnAgain'), btnClose = $('btnClose');
const timerEl = $('timer'), metaEl = $('meta'), recDot = $('recDot');
const preview = $('preview'), previewBox = $('previewBox');
const loading = $('loading'), loadingText = $('loadingText'), errBox = $('errBox');

let stream = null, micStream = null, audioCtx = null;
let recorder = null, recorderStream = null;
let chunks = [];
let startedAt = 0, pausedAccum = 0, pauseAt = 0;
let timerId = null;
let stopping = false;

// ---------- URL 参数 ----------
const params = new URLSearchParams(location.search);
if (params.get('sys') !== null) optSys.checked = params.get('sys') === '1';
if (params.get('mic') !== null) optMic.checked = params.get('mic') === '1';

// ---------- 开始 ----------
btnStart.onclick = async () => {
  btnStart.disabled = true;
  errBox.textContent = '';
  loadingText.textContent = '请在弹出窗口中选择要录制的屏幕或窗口…';
  loading.style.display = 'flex';

  try {
    stream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: { ideal: 30, max: 60 } },
      audio: optSys.checked
        ? { echoCancellation: false, noiseSuppression: false, autoGainControl: false }
        : false
    });
  } catch (e) {
    loading.style.display = 'none';
    btnStart.disabled = false;
    errBox.textContent = '未获得屏幕共享权限：' + e.message;
    return;
  }

  if (optMic.checked) {
    try {
      micStream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
      });
    } catch (e) { console.warn('mic failed:', e.message); }
  }

  const videoTrack = stream.getVideoTracks()[0];
  const sysTracks = stream.getAudioTracks();

  try {
    recorderStream = new MediaStream();
    recorderStream.addTrack(videoTrack);

    if (sysTracks.length || micStream) {
      audioCtx = new AudioContext();
      const dest = audioCtx.createMediaStreamDestination();
      if (sysTracks.length) {
        audioCtx.createMediaStreamSource(new MediaStream(sysTracks)).connect(dest);
      }
      if (micStream) {
        audioCtx.createMediaStreamSource(micStream).connect(dest);
      }
      if (audioCtx.state === 'suspended') await audioCtx.resume();
      dest.stream.getAudioTracks().forEach(t => recorderStream.addTrack(t));
    }

    const mime = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']
      .find(m => MediaRecorder.isTypeSupported(m)) || 'video/webm';

    recorder = new MediaRecorder(recorderStream, {
      mimeType: mime,
      videoBitsPerSecond: 8000000,
      audioBitsPerSecond: 128000
    });
    chunks = [];
    recorder.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
    recorder.onstop = onRecordStop;
    recorder.start(1000);

    startedAt = Date.now();
    pausedAccum = 0; pauseAt = 0; stopping = false;

    await chrome.runtime.sendMessage({
      type: 'REC_STATUS',
      host: 'recorder-tab',
      patch: {
        status: 'recording', mode: 'full',
        startedAt, pausedAccum: 0, pausedAt: 0,
        hasSysAudio: sysTracks.length > 0, hasMic: !!micStream,
        host: 'recorder-tab', region: null
      }
    }).catch(() => {});

    enterRecordingUI(videoTrack, sysTracks.length > 0);

    videoTrack.addEventListener('ended', () => {
      if (recorder && recorder.state !== 'inactive') recorder.stop();
    });

  } catch (e) {
    loading.style.display = 'none';
    btnStart.disabled = false;
    errBox.textContent = '启动录制失败：' + e.message;
    cleanupStreams();
  }
};

btnCancel.onclick = async () => {
  await chrome.runtime.sendMessage({ type: 'CLOSE_HOST_TABS' }).catch(() => {});
  window.close();
};

// ---------- 录制中界面 ----------
function enterRecordingUI(videoTrack, hasSysAudio) {
  loading.style.display = 'none';
  readyPanel.style.display = 'none';
  recPanel.style.display = 'block';

  preview.srcObject = stream;
  previewBox.style.display = 'block';

  const st = videoTrack.getSettings ? videoTrack.getSettings() : {};
  const pills = [];
  const label = (videoTrack.label || '屏幕共享').slice(0, 30);
  pills.push(`<span class="pill">${escapeHtml(label)}</span>`);
  if (st.width && st.height) pills.push(`<span class="pill">${st.width} × ${st.height}</span>`);
  pills.push(`<span class="pill">${st.frameRate ? Math.round(st.frameRate) + ' fps' : '30 fps'}</span>`);
  if (hasSysAudio) pills.push('<span class="pill ok">🔊 系统声音</span>');
  if (micStream) pills.push('<span class="pill ok">🎤 麦克风</span>');
  if (!hasSysAudio && !micStream) pills.push('<span class="pill">静音</span>');
  metaEl.innerHTML = pills.join('');

  tick();
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function elapsedSec() {
  if (!startedAt) return 0;
  const now = (recorder && recorder.state === 'paused' && pauseAt) ? pauseAt : Date.now();
  return Math.max(0, Math.floor((now - startedAt - pausedAccum) / 1000));
}

function fmt(s) {
  return [Math.floor(s / 3600), Math.floor(s % 3600 / 60), s % 60]
    .map(n => String(n).padStart(2, '0')).join(':');
}

function tick() {
  if (!recorder || recorder.state === 'inactive') return;
  timerEl.textContent = fmt(elapsedSec());
  const paused = recorder.state === 'paused';
  timerEl.classList.toggle('paused', paused);
  recDot.classList.toggle('paused', paused);
  timerId = setTimeout(tick, 400);
}

// ---------- 暂停 / 继续 ----------
function togglePause() {
  if (!recorder) return;
  if (recorder.state === 'recording') {
    recorder.pause();
    pauseAt = Date.now();
    btnPause.textContent = '继续';
    chrome.runtime.sendMessage({
      type: 'REC_STATUS', host: 'recorder-tab',
      patch: { status: 'paused', pausedAt: pauseAt }
    }).catch(() => {});
  } else if (recorder.state === 'paused') {
    recorder.resume();
    pausedAccum += Date.now() - pauseAt;
    pauseAt = 0;
    btnPause.textContent = '暂停';
    chrome.runtime.sendMessage({
      type: 'REC_STATUS', host: 'recorder-tab',
      patch: { status: 'recording', pausedAccum, pausedAt: 0 }
    }).catch(() => {});
  }
  tick();
}
btnPause.onclick = togglePause;

// ---------- 停止 ----------
btnStop.onclick = () => {
  btnStop.disabled = true;
  btnPause.disabled = true;
  if (recorder && recorder.state !== 'inactive') recorder.stop();
  else onRecordStop();
};

function onRecordStop() {
  if (stopping) return;
  stopping = true;
  if (timerId) clearTimeout(timerId);

  const totalSec = elapsedSec();
  const type = (recorder && recorder.mimeType) || 'video/webm';
  const blob = new Blob(chunks, { type });
  const sizeMB = (blob.size / 1048576).toFixed(2);
  const filename = `录屏_${tsString()}_全屏.webm`;

  // 大文件用 blobURL（本页存活期间有效），小文件用 dataURL 更稳
  if (blob.size > 8 * 1024 * 1024) {
    const url = URL.createObjectURL(blob);
    chrome.runtime.sendMessage({ type: 'REC_DONE', url, filename, sizeMB }).catch(() => {});
    showDone(filename, sizeMB, totalSec);
    setTimeout(() => { try { URL.revokeObjectURL(url); } catch (e) {} }, 120000);
  } else {
    const reader = new FileReader();
    reader.onload = () => {
      chrome.runtime.sendMessage({
        type: 'REC_DONE', dataUrl: reader.result, filename, sizeMB
      }).catch(() => {});
      showDone(filename, sizeMB, totalSec);
    };
    reader.onerror = () => showDone(filename, sizeMB, totalSec, true);
    reader.readAsDataURL(blob);
  }

  cleanupStreams();
}

function showDone(filename, sizeMB, totalSec, failed) {
  recPanel.style.display = 'none';
  donePanel.style.display = 'block';
  previewBox.style.display = 'none';
  $('doneTitle').textContent = failed ? '⚠️ 录制已结束' : '✅ 录制完成';
  $('doneDesc').innerHTML = failed
    ? `文件生成失败，请重试。<br>已录制时长 ${fmt(totalSec)}`
    : `文件 <b style="color:#66bb6a">${escapeHtml(filename)}</b><br>` +
      `时长 ${fmt(totalSec)}　·　大小 ${sizeMB} MB<br>` +
      `<span style="font-size:12px;color:#6b7488">已弹出保存对话框，请选择保存位置</span>`;
}

// ---------- 再录一次 ----------
btnAgain.onclick = () => {
  donePanel.style.display = 'none';
  readyPanel.style.display = 'block';
  btnStart.disabled = false;
  btnStop.disabled = false;
  btnPause.disabled = false;
  btnPause.textContent = '暂停';
  timerEl.textContent = '00:00:00';
  timerEl.classList.remove('paused');
  errBox.textContent = '';
  recorder = null; recorderStream = null; chunks = [];
  startedAt = 0; pausedAccum = 0; pauseAt = 0; stopping = false;
};

btnClose.onclick = () => window.close();

// ---------- 清理 ----------
function cleanupStreams() {
  if (timerId) { clearTimeout(timerId); timerId = null; }
  [stream, micStream].forEach(s => { if (s) s.getTracks().forEach(t => t.stop()); });
  stream = null; micStream = null;
  if (audioCtx) { audioCtx.close().catch(() => {}); audioCtx = null; }
  preview.srcObject = null;
}

function tsString() {
  const d = new Date();
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_` +
         `${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

// ---------- 远程控制（来自 popup） ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === 'REMOTE_PAUSE_TOGGLE') {
    togglePause();
    sendResponse({ ok: true, state: recorder ? recorder.state : 'none' });
  }
  if (msg.type === 'REMOTE_STOP') {
    if (recorder && recorder.state !== 'inactive') {
      btnStop.disabled = true;
      btnPause.disabled = true;
      recorder.stop();
    }
    sendResponse({ ok: true });
  }
  return true;
});

// ---------- 关闭保护 ----------
window.addEventListener('beforeunload', e => {
  if (recorder && recorder.state !== 'inactive') {
    e.preventDefault();
    e.returnValue = '正在录制中，关闭页面将结束录制并丢失未保存内容';
    return e.returnValue;
  }
  cleanupStreams();
  chrome.runtime.sendMessage({ type: 'HOST_CLOSED', host: 'recorder-tab' }).catch(() => {});
});

// ---------- 初始检查 ----------
(async () => {
  const st = await chrome.runtime.sendMessage({ type: 'GET_STATE' }).catch(() => null);
  if (st && (st.status === 'recording' || st.status === 'paused') && st.host !== 'recorder-tab') {
    errBox.textContent = '当前已有录制任务进行中，请先结束后再开始新的录制';
    btnStart.disabled = true;
  }
})();
