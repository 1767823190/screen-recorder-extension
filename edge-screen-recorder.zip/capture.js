// capture.js —— 区域框选 + 裁剪录制（Edge）
// 三个视图：intro（说明）→ stage（框选）→ recView（录制中）→ doneView（完成）

const $ = id => document.getElementById(id);
const intro = $('intro'), stage = $('stage'), recView = $('recView'), doneView = $('doneView');
const preview = $('preview'), mask = $('mask'), sel = $('sel'), grid = $('grid');
const sizeTag = $('sizeTag'), toolbar = $('toolbar'), toolInfo = $('toolInfo');
const optSys = $('optSys'), optMic = $('optMic');
const btnShare = $('btnShare'), btnCancel = $('btnCancel');
const btnReset = $('btnReset'), btnConfirm = $('btnConfirm');
const loading = $('loading'), loadingText = $('loadingText'), errBox = $('errBox');
const recTimer = $('recTimer'), recDot = $('recDot'), recPills = $('recPills');
const btnRecPause = $('btnRecPause'), btnRecStop = $('btnRecStop');
const liveCanvas = $('liveCanvas');

let stream = null, micStream = null, audioCtx = null;
let recorder = null, chunks = [];
let canvas = null, ctx = null, canvasStream = null, drawRAF = null;
let region = null;             // 视频原始像素 {x,y,w,h}
let dragging = false, startX = 0, startY = 0;
let startedAt = 0, pausedAccum = 0, pauseAt = 0;
let timerId = null, stopping = false;

// ---------- URL 参数 ----------
const params = new URLSearchParams(location.search);
if (params.get('sys') !== null) optSys.checked = params.get('sys') === '1';
if (params.get('mic') !== null) optMic.checked = params.get('mic') === '1';

// ==================================================================
// 阶段1：申请屏幕共享
// ==================================================================
btnShare.onclick = async () => {
  btnShare.disabled = true;
  errBox.textContent = '';
  loadingText.textContent = '请在弹出窗口中选择要共享的屏幕或窗口…';
  loading.style.display = 'flex';

  try {
    stream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: { ideal: 30, max: 60 } },
      audio: optSys.checked
        ? { echoCancellation: false, noiseSuppression: false, autoGainControl: false }
        : false
    });
  } catch (e) {
    loading.style.display = 'none';
    btnShare.disabled = false;
    errBox.textContent = '未获得屏幕共享权限：' + e.message;
    return;
  }

  preview.srcObject = stream;
  loadingText.textContent = '正在载入画面…';

  if (preview.readyState < 2) {
    await new Promise(r => preview.addEventListener('loadedmetadata', r, { once: true }));
    await new Promise(r => preview.addEventListener('playing', r, { once: true }));
  }
  await new Promise(r => setTimeout(r, 180));

  loading.style.display = 'none';
  intro.style.display = 'none';
  stage.style.display = 'block';
  toolbar.style.display = 'flex';
  requestAnimationFrame(() => {
    toolbar.classList.add('show');
    alignOverlay();
  });
};

btnCancel.onclick = async () => {
  await chrome.runtime.sendMessage({ type: 'CLOSE_HOST_TABS' }).catch(() => {});
  window.close();
};

// ==================================================================
// 坐标对齐：视频使用 object-fit:contain，需要计算实际显示区域
// ==================================================================
let viewBox = { left: 0, top: 0, width: 0, height: 0, scale: 1 };

function alignOverlay() {
  const vw = preview.videoWidth, vh = preview.videoHeight;
  if (!vw || !vh) return;

  const pw = window.innerWidth, ph = window.innerHeight;
  const scale = Math.min(pw / vw, ph / vh);
  const dw = vw * scale, dh = vh * scale;

  viewBox = {
    left: (pw - dw) / 2,
    top: (ph - dh) / 2,
    width: dw,
    height: dh,
    scale
  };

  // 遮罩只覆盖视频显示区域，避免在留白上拖拽
  mask.style.left = viewBox.left + 'px';
  mask.style.top = viewBox.top + 'px';
  mask.style.width = viewBox.width + 'px';
  mask.style.height = viewBox.height + 'px';

  if (region) renderRegion();
}

window.addEventListener('resize', alignOverlay);

// ==================================================================
// 阶段2：拖拽框选
// ==================================================================
mask.addEventListener('mousedown', e => {
  if (e.button !== 0) return;
  e.preventDefault();
  dragging = true;
  startX = e.clientX;
  startY = e.clientY;
  sel.style.display = 'block';
  grid.style.display = 'block';
  btnConfirm.disabled = true;
  updateSel(startX, startY, 0, 0);
});

window.addEventListener('mousemove', e => {
  if (!dragging) return;
  updateSel(startX, startY, e.clientX - startX, e.clientY - startY);
});

window.addEventListener('mouseup', e => {
  if (!dragging) return;
  dragging = false;
  grid.style.display = 'none';

  const b = viewBox;
  const x1 = clamp(Math.min(startX, e.clientX), b.left, b.left + b.width);
  const y1 = clamp(Math.min(startY, e.clientY), b.top, b.top + b.height);
  const x2 = clamp(Math.max(startX, e.clientX), b.left, b.left + b.width);
  const y2 = clamp(Math.max(startY, e.clientY), b.top, b.top + b.height);

  const w = x2 - x1, h = y2 - y1;

  if (w < 14 || h < 14) {
    sel.style.display = 'none';
    btnConfirm.disabled = true;
    toolInfo.textContent = '选区太小，请重新拖拽框选（至少 14 × 14）';
    return;
  }

  // 显示像素 → 视频原始像素
  const s = b.scale;
  const rx = Math.round((x1 - b.left) / s);
  const ry = Math.round((y1 - b.top) / s);
  const rw = Math.round(w / s);
  const rh = Math.round(h / s);

  region = {
    x: clamp(rx, 0, preview.videoWidth - 4),
    y: clamp(ry, 0, preview.videoHeight - 4),
    w: 0, h: 0
  };
  region.w = Math.min(rw, preview.videoWidth - region.x);
  region.h = Math.min(rh, preview.videoHeight - region.y);

  renderRegion();
  btnConfirm.disabled = false;

  toolInfo.innerHTML =
    `已选 <b>${region.w} × ${region.h}</b>　源 ${preview.videoWidth}×${preview.videoHeight}`;
});

function updateSel(x1, y1, dw, dh) {
  const b = viewBox;
  let x = clamp(Math.min(x1, x1 + dw), b.left, b.left + b.width);
  let y = clamp(Math.min(y1, y1 + dh), b.top, b.top + b.height);
  let w = Math.min(Math.abs(dw), b.left + b.width - x);
  let h = Math.min(Math.abs(dh), b.top + b.height - y);

  sel.style.left = x + 'px';
  sel.style.top = y + 'px';
  sel.style.width = w + 'px';
  sel.style.height = h + 'px';

  grid.style.left = x + 'px';
  grid.style.top = y + 'px';
  grid.style.width = w + 'px';
  grid.style.height = h + 'px';

  const s = b.scale || 1;
  const rw = Math.round(w / s), rh = Math.round(h / s);

  sizeTag.style.display = 'block';
  sizeTag.textContent = `${rw} × ${rh}`;
  sizeTag.style.left = clamp(x + 4, 4, window.innerWidth - 130) + 'px';
  sizeTag.style.top = (y - 30 < 4 ? y + 8 : y - 30) + 'px';
}

function renderRegion() {
  const b = viewBox, s = b.scale || 1;
  sel.style.display = 'block';
  sel.style.left = (b.left + region.x * s) + 'px';
  sel.style.top = (b.top + region.y * s) + 'px';
  sel.style.width = (region.w * s) + 'px';
  sel.style.height = (region.h * s) + 'px';
  sizeTag.style.display = 'block';
  sizeTag.textContent = `${region.w} × ${region.h}`;
  sizeTag.style.left = (b.left + region.x * s + 4) + 'px';
  sizeTag.style.top = (b.top + region.y * s - 30) + 'px';
}

function clamp(v, a, b) { return Math.max(a, Math.min(v, b)); }

btnReset.onclick = () => {
  region = null;
  sel.style.display = 'none';
  sizeTag.style.display = 'none';
  btnConfirm.disabled = true;
  toolInfo.textContent = '按住鼠标拖拽框选区域';
};

// ==================================================================
// 阶段3：确认 → 裁剪录制
// ==================================================================
btnConfirm.onclick = async () => {
  if (!region) return;
  btnConfirm.disabled = true;
  btnReset.disabled = true;
  loadingText.textContent = '正在启动录制引擎…';
  loading.style.display = 'flex';

  try {
    // 偶数尺寸，规避部分编码器对奇数宽高的问题
    const w = Math.max(2, Math.floor(region.w / 2) * 2);
    const h = Math.max(2, Math.floor(region.h / 2) * 2);

    canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });

    // 实时预览画布
    liveCanvas.width = w;
    liveCanvas.height = h;

    const drawFrame = () => {
      if (preview.readyState >= 2) {
        try {
          ctx.drawImage(preview, region.x, region.y, w, h, 0, 0, w, h);
          // 同步到预览画布（降采样以省性能）
          const lc = liveCanvas.getContext('2d');
          lc.drawImage(canvas, 0, 0, liveCanvas.width, liveCanvas.height);
        } catch (e) { /* 偶发错误忽略 */ }
      }
      drawRAF = requestAnimationFrame(drawFrame);
    };
    drawFrame();

    canvasStream = canvas.captureStream(30);
    const finalStream = new MediaStream();
    canvasStream.getVideoTracks().forEach(t => finalStream.addTrack(t));

    // 麦克风
    if (optMic.checked) {
      try {
        micStream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
        });
      } catch (e) { console.warn('mic failed', e.message); }
    }

    // 音频混合
    const sysTracks = stream.getAudioTracks();
    const hasAudio = sysTracks.length > 0 || !!micStream;
    if (hasAudio) {
      audioCtx = new AudioContext();
      const dest = audioCtx.createMediaStreamDestination();
      if (sysTracks.length) {
        audioCtx.createMediaStreamSource(new MediaStream(sysTracks)).connect(dest);
      }
      if (micStream) {
        audioCtx.createMediaStreamSource(micStream).connect(dest);
      }
      if (audioCtx.state === 'suspended') await audioCtx.resume();
      dest.stream.getAudioTracks().forEach(t => finalStream.addTrack(t));
    }

    const mime = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']
      .find(m => MediaRecorder.isTypeSupported(m)) || 'video/webm';

    recorder = new MediaRecorder(finalStream, {
      mimeType: mime,
      videoBitsPerSecond: Math.min(8000000, Math.max(2000000, w * h * 0.8)),
      audioBitsPerSecond: 128000
    });
    chunks = [];
    recorder.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
    recorder.onstop = onRecordStop;
    recorder.start(1000);

    startedAt = Date.now();
    pausedAccum = 0; pauseAt = 0; stopping = false;

    await chrome.runtime.sendMessage({
      type: 'REC_STATUS',
      host: 'capture-tab',
      patch: {
        status: 'recording', mode: 'region',
        startedAt, pausedAccum: 0, pausedAt: 0,
        region: { x: region.x, y: region.y, w, h },
        hasSysAudio: sysTracks.length > 0,
        hasMic: !!micStream,
        host: 'capture-tab'
      }
    }).catch(() => {});

    // 切到录制中界面
    loading.style.display = 'none';
    stage.style.display = 'none';
    toolbar.classList.remove('show');
    toolbar.style.display = 'none';
    intro.style.display = 'none';
    recView.style.display = 'block';

    const pills = [
      `<span class="pill">${w} × ${h}</span>`,
      `<span class="pill">裁剪偏移 ${region.x},${region.y}</span>`
    ];
    if (sysTracks.length) pills.push('<span class="pill ok">🔊 系统声音</span>');
    if (micStream) pills.push('<span class="pill ok">🎤 麦克风</span>');
    if (!hasAudio) pills.push('<span class="pill">静音</span>');
    recPills.innerHTML = pills.join('');

    tick();

    // 用户点「停止共享」
    stream.getVideoTracks()[0].addEventListener('ended', () => {
      if (recorder && recorder.state !== 'inactive') recorder.stop();
    });

  } catch (e) {
    loading.style.display = 'none';
    btnConfirm.disabled = false;
    btnReset.disabled = false;
    errBox.textContent = '启动录制失败：' + e.message;
  }
};

// ---------- 计时 ----------
function elapsedSec() {
  if (!startedAt) return 0;
  const now = (recorder && recorder.state === 'paused' && pauseAt) ? pauseAt : Date.now();
  return Math.max(0, Math.floor((now - startedAt - pausedAccum) / 1000));
}
function fmt(s) {
  return [Math.floor(s / 3600), Math.floor(s % 3600 / 60), s % 60]
    .map(n => String(n).padStart(2, '0')).join(':');
}
function tick() {
  if (!recorder || recorder.state === 'inactive') return;
  recTimer.textContent = fmt(elapsedSec());
  const paused = recorder.state === 'paused';
  recTimer.classList.toggle('paused', paused);
  recDot.classList.toggle('paused', paused);
  timerId = setTimeout(tick, 400);
}

// ---------- 暂停 ----------
function togglePause() {
  if (!recorder) return;
  if (recorder.state === 'recording') {
    recorder.pause();
    pauseAt = Date.now();
    btnRecPause.textContent = '继续';
    chrome.runtime.sendMessage({
      type: 'REC_STATUS', host: 'capture-tab',
      patch: { status: 'paused', pausedAt: pauseAt }
    }).catch(() => {});
  } else if (recorder.state === 'paused') {
    recorder.resume();
    pausedAccum += Date.now() - pauseAt;
    pauseAt = 0;
    btnRecPause.textContent = '暂停';
    chrome.runtime.sendMessage({
      type: 'REC_STATUS', host: 'capture-tab',
      patch: { status: 'recording', pausedAccum, pausedAt: 0 }
    }).catch(() => {});
  }
  tick();
}
btnRecPause.onclick = togglePause;

// ---------- 停止 ----------
btnRecStop.onclick = () => {
  btnRecStop.disabled = true;
  btnRecPause.disabled = true;
  if (recorder && recorder.state !== 'inactive') recorder.stop();
  else onRecordStop();
};

function onRecordStop() {
  if (stopping) return;
  stopping = true;
  if (timerId) clearTimeout(timerId);
  if (drawRAF) cancelAnimationFrame(drawRAF);

  const totalSec = elapsedSec();
  const type = (recorder && recorder.mimeType) || 'video/webm';
  const blob = new Blob(chunks, { type });
  const sizeMB = (blob.size / 1048576).toFixed(2);
  const filename = `录屏_${tsString()}_区域.webm`;

  const finishUI = (failed) => {
    recView.style.display = 'none';
    doneView.style.display = 'block';
    $('doneDesc').innerHTML = failed
      ? `文件生成失败，请重试。<br>已录制时长 ${fmt(totalSec)}`
      : `文件 <b style="color:#66bb6a">${filename}</b><br>` +
        `时长 ${fmt(totalSec)}　·　大小 ${sizeMB} MB<br>` +
        `<span style="font-size:12px;color:#6b7488">已弹出保存对话框，请选择保存位置</span>`;
  };

  if (blob.size > 8 * 1024 * 1024) {
    const url = URL.createObjectURL(blob);
    chrome.runtime.sendMessage({ type: 'REC_DONE', url, filename, sizeMB }).catch(() => {});
    finishUI(false);
    setTimeout(() => { try { URL.revokeObjectURL(url); } catch (e) {} }, 120000);
  } else {
    const reader = new FileReader();
    reader.onload = () => {
      chrome.runtime.sendMessage({
        type: 'REC_DONE', dataUrl: reader.result, filename, sizeMB
      }).catch(() => {});
      finishUI(false);
    };
    reader.onerror = () => finishUI(true);
    reader.readAsDataURL(blob);
  }

  cleanupStreams();
}

$('btnDoneClose').onclick = () => window.close();

// ---------- 清理 ----------
function cleanupStreams() {
  if (timerId) { clearTimeout(timerId); timerId = null; }
  if (drawRAF) { cancelAnimationFrame(drawRAF); drawRAF = null; }
  [stream, micStream, canvasStream].forEach(s => {
    if (s) s.getTracks().forEach(t => t.stop());
  });
  stream = micStream = canvasStream = null;
  if (audioCtx) { audioCtx.close().catch(() => {}); audioCtx = null; }
  preview.srcObject = null;
}

function tsString() {
  const d = new Date();
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_` +
         `${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

// ---------- 远程控制 ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === 'REMOTE_PAUSE_TOGGLE') {
    togglePause();
    sendResponse({ ok: true });
  }
  if (msg.type === 'REMOTE_STOP') {
    if (recorder && recorder.state !== 'inactive') {
      btnRecStop.disabled = true;
      btnRecPause.disabled = true;
      recorder.stop();
    }
    sendResponse({ ok: true });
  }
  return true;
});

// ---------- 关闭保护 ----------
window.addEventListener('beforeunload', e => {
  if (recorder && recorder.state !== 'inactive') {
    e.preventDefault();
    e.returnValue = '区域录制中，关闭页面将中断录制并丢失内容';
    return e.returnValue;
  }
  cleanupStreams();
  chrome.runtime.sendMessage({ type: 'HOST_CLOSED', host: 'capture-tab' }).catch(() => {});
});

// ---------- 初始检查 ----------
(async () => {
  const st = await chrome.runtime.sendMessage({ type: 'GET_STATE' }).catch(() => null);
  if (st && (st.status === 'recording' || st.status === 'paused') && st.host !== 'capture-tab') {
    errBox.textContent = '当前已有录制任务进行中，请先结束后再框选新区域';
    btnShare.disabled = true;
  }
})();
