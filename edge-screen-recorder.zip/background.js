// background.js - Edge MV3 Service Worker
// 架构说明（Edge 兼容要点）：
//   pgetDisplayMedia 必须有用户激活手势，offscreen document 拿不到手势，
//   因此全屏录制由 popup 拿到 MediaStream 后，通过 offscreen 中转录制不可行。
//   本版本采用：
//     1) 全屏/窗口录制 —— 在「录制页 recorder.html」中完成（有用户手势，可弹共享窗）
//     2) 区域录制     —— 在「框选页 capture.html」中完成（框选后同一页裁剪录制）
//   popup 只做控制面板；两者都通过 storage.session 读写状态，因此关掉 popup 录制不中断。

const STATE_KEY = 'recorderState';
const CAPTURE_URL = 'capture.html';
const RECORDER_URL = 'recorder.html';

let state = {
  status: 'idle',        // idle | recording | paused
  mode: 'full',          // full | region
  startedAt: 0,
  pausedAccum: 0,
  pausedAt: 0,
  region: null,
  hasMic: false,
  hasSysAudio: false,
  host: null             // recorder-tab | capture-tab
};

async function setState(patch) {
  state = { ...state, ...patch };
  try { await chrome.storage.session.set({ [STATE_KEY]: state }); } catch (e) {}
  chrome.runtime.sendMessage({ type: 'STATE_UPDATE', state }).catch(() => {});
  updateBadge(state.status);
}

async function loadState() {
  try {
    const got = await chrome.storage.session.get(STATE_KEY);
    if (got[STATE_KEY]) state = got[STATE_KEY];
  } catch (e) {}
  return state;
}

function updateBadge(status) {
  const map = {
    recording: ['REC', '#e94560'],
    paused: ['PAUSE', '#ff9800']
  };
  const [text, color] = map[status] || ['', '#000000'];
  try {
    chrome.action.setBadgeText({ text });
    if (text) chrome.action.setBadgeBackgroundColor({ color });
  } catch (e) {}
}

// ---------- 标签页管理 ----------
async function findTab(url) {
  const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL(url) + '*' });
  return tabs[0] || null;
}

async function openTab(url, query) {
  const existing = await findTab(url);
  if (existing) {
    await chrome.tabs.update(existing.id, { active: true });
    return existing.id;
  }
  const tab = await chrome.tabs.create({
    url: chrome.runtime.getURL(url) + (query ? '?' + query : ''),
    active: true
  });
  return tab.id;
}

async function closeTabs(url) {
  const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL(url) + '*' });
  for (const t of tabs) {
    try { await chrome.tabs.remove(t.id); } catch (e) {}
  }
}

async function closeAllHostTabs() {
  await closeTabs(CAPTURE_URL);
  await closeTabs(RECORDER_URL);
}

// ---------- 消息路由 ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  (async () => {
    switch (msg.type) {

      // popup 点击开始（全屏/窗口）
      case 'START_FULL': {
        await setState({ mode: 'full' });
        const q = `mode=full&mic=${msg.mic ? 1 : 0}&sys=${msg.sysAudio ? 1 : 0}`;
        await openTab(RECORDER_URL, q);
        sendResponse({ ok: true });
        break;
      }

      // popup 点击开始（自选区域）
      case 'START_REGION': {
        await setState({ mode: 'region' });
        const q = `mode=region&mic=${msg.mic ? 1 : 0}&sys=${msg.sysAudio ? 1 : 0}`;
        await openTab(CAPTURE_URL, q);
        sendResponse({ ok: true });
        break;
      }

      // 录制页/框选页回报状态
      case 'REC_STATUS': {
        await setState({ ...msg.patch, host: msg.host || state.host });
        sendResponse({ ok: true });
        break;
      }

      // 录制完成
      case 'REC_DONE': {
        const url = msg.dataUrl || msg.url;
        try {
          await chrome.downloads.download({
            url,
            filename: msg.filename,
            saveAs: true
          });
        } catch (e) {
          console.warn('download failed:', e.message);
        }
        await setState({
          status: 'idle', region: null, startedAt: 0,
          pausedAccum: 0, pausedAt: 0, hasMic: false,
          hasSysAudio: false, host: null
        });
        chrome.runtime.sendMessage({
          type: 'REC_SAVED',
          filename: msg.filename,
          sizeMB: msg.sizeMB
        }).catch(() => {});
        notify('录制完成', `${msg.filename}（${msg.sizeMB} MB）已保存`);
        sendResponse({ ok: true });
        break;
      }

      // popup 请求暂停/继续：转发给宿主页
      case 'PAUSE_TOGGLE': {
        await loadState();
        const hostUrl = state.host === 'capture-tab' ? CAPTURE_URL : RECORDER_URL;
        const tab = await findTab(hostUrl);
        if (!tab) { sendResponse({ ok: false, error: '未找到录制页面' }); break; }
        try {
          const r = await chrome.tabs.sendMessage(tab.id, { type: 'REMOTE_PAUSE_TOGGLE' });
          sendResponse({ ok: true, result: r });
        } catch (e) {
          sendResponse({ ok: false, error: e.message });
        }
        break;
      }

      // popup 请求停止：转发给宿主页
      case 'STOP': {
        await loadState();
        const hostUrl = state.host === 'capture-tab' ? CAPTURE_URL : RECORDER_URL;
        const tab = await findTab(hostUrl);
        if (!tab) { sendResponse({ ok: false, error: '未找到录制页面' }); break; }
        try {
          await chrome.tabs.sendMessage(tab.id, { type: 'REMOTE_STOP' });
          sendResponse({ ok: true });
        } catch (e) {
          sendResponse({ ok: false, error: e.message });
        }
        break;
      }

      case 'CLOSE_HOST_TABS': {
        await closeAllHostTabs();
        sendResponse({ ok: true });
        break;
      }

      case 'GET_STATE': {
        sendResponse(await loadState());
        break;
      }

      // 页面主动关闭时的清理
      case 'HOST_CLOSED': {
        await loadState();
        if (msg.host === state.host) {
          await setState({
            status: 'idle', host: null, region: null,
            startedAt: 0, pausedAccum: 0, pausedAt: 0
          });
        }
        sendResponse({ ok: true });
        break;
      }
    }
  })();

  return true;
});

function notify(title, message) {
  try {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title,
      message
    });
  } catch (e) {}
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.session.set({ [STATE_KEY]: state });
  updateBadge('idle');
});

chrome.runtime.onStartup.addListener(() => {
  updateBadge('idle');
});
